import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blocked-accounts',
  templateUrl: './blocked-accounts.component.html',
  styleUrls: ['./blocked-accounts.component.css']
})
export class BlockedAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
