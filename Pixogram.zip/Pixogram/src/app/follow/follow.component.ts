import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../models/User';
import { Router } from '@angular/router';
import { FollowService } from '../follow.service';
import { Follow } from '../models/follow';

@Component({
  selector: 'app-follow',
  templateUrl: './follow.component.html',
  styleUrls: ['./follow.component.css']
})
export class FollowComponent implements OnInit {
  public users:User[];
  fid: number;
 
  
  constructor(private router: Router,public userService:UserService,public userFollow:FollowService) {

  }

 ngOnInit() {
   this.userService.getUsers().subscribe(response => this.users = response);
   
 }

 onFollow(i:User){
  
    //this.submitted = true;
    //console.log(i.username);
    console.log(i.id);
    
   // this.fid=i.id;
    let userf = new Follow(this.userService.userId,i.id);
    this.userFollow.create(userf)
    .subscribe(data => console.log(data), error => console.log(error));
    console.log(i.id);
    console.log(userf);
   // this.userService.username=this.user_name;
   
      this.router.navigate(['Following']);
  
  }

}

